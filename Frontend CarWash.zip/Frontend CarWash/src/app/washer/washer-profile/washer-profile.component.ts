import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-washer-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './washer-profile.component.html',
  styleUrls: ['./washer-profile.component.css']
})
export class WasherProfileComponent implements OnInit {
  washer: any = {};
  washerId: string | number | null = null;

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.fetchWasherData();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) throw new Error('Missing authentication token');

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
  }

  fetchWasherData(): void {
    const token = this.authService.getToken();
    if (!token) {
      console.error('No token found');
      return;
    }

    const email = this.authService.extractEmailFromToken(token);
    const headers = this.getAuthHeaders();

    this.http.get(`http://localhost:8080/api/washers/email/${email}`, { headers }).subscribe({
      next: (response: any) => {
        console.log('Washer data:', response);
        this.washer = response;
        this.washerId = response.id;
      },
      error: (error: any) => {
        console.error('Error fetching washer data:', error);
      }
    });
  }

  updateProfile(): void {
    if (!this.washerId) return;

    const headers = this.getAuthHeaders();
    this.http.put(`http://localhost:8080/api/washers/${this.washerId}`, this.washer, { headers }).subscribe({
      next: () => alert('Profile updated successfully!'),
      error: (err) => console.error('Failed to update profile:', err)
    });
  }
}