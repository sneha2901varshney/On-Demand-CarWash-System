import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../../core/auth.service';
import { WasherService } from '../../core/washer.service';

@Component({
  selector: 'app-current-orders',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './current-orders.component.html',
  styleUrls: ['./current-orders.component.css']
})
export class CurrentOrdersComponent implements OnInit {
  orders: any[] = [];
  washerId: string | number | null = null;
  statusUpdate: { [key: number]: { status: string; imageUrl: string } } = {};

  constructor(
    private washerService: WasherService,
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.fetchWasherId();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) throw new Error('Missing authentication token');

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
  }

  fetchWasherId(): void {
    const token = this.authService.getToken();
    if (!token) {
      console.error('No token found');
      return;
    }

    const email = this.authService.extractEmailFromToken(token);
    const headers = this.getAuthHeaders();

    this.http.get(`http://localhost:8080/api/washers/email/${email}`, { headers }).subscribe({
      next: (response: any) => {
        console.log('Washer data:', response);
        this.washerId = response.id;
        this.loadCurrentOrders(); // Fetch orders after getting washer ID
      },
      error: (error: any) => {
        console.error('Error fetching washer data:', error);
      }
    });
  }

  loadCurrentOrders(): void {
    if (!this.washerId) return;

    this.washerService.getCurrentOrders(String(this.washerId)).subscribe({
      next: (data) => {
        this.orders = data;
        // Initialize statusUpdate for each order
        this.orders.forEach(order => {
          if (!this.statusUpdate[order.id]) {
            this.statusUpdate[order.id] = { status: '', imageUrl: '' };
          }
        });
      },
      error: (err) => {
        console.error('Failed to load current orders:', err);
      }
    });
  }

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('washerActivities') || '[]');
    activities.unshift(newActivity);
    activities.splice(10);
    localStorage.setItem('washerActivities', JSON.stringify(activities));
  }

  updateOrderInLocalStorage(orderId: number, status: string): void {
    const orders = JSON.parse(localStorage.getItem('washerOrders') || '[]');
    const orderIndex = orders.findIndex((order: any) => order.id === orderId);
    if (orderIndex >= 0) {
      orders[orderIndex].status = status;
      orders[orderIndex].dateUpdated = new Date().toISOString();
      localStorage.setItem('washerOrders', JSON.stringify(orders));
    }
  }

  updateStatus(orderId: number): void {
    const update = this.statusUpdate[orderId];
    if (!update?.status) {
      alert('Please enter status');
      return;
    }

    this.washerService.updateOrderStatus(orderId, update.status, update.imageUrl).subscribe({
      next: () => {
        alert('Status updated');
        if (update.status === 'COMPLETED') {
          this.addActivity('order_completed', `Order #${orderId} completed successfully`);
          this.addActivity('payment_received', `Payment received for order #${orderId}`);
        } else {
          this.addActivity('order_updated', `Order #${orderId} status updated to ${update.status}`);
        }
        this.updateOrderInLocalStorage(orderId, update.status);
        this.loadCurrentOrders();
      },
      error: () => alert('Failed to update status')
    });
  }
}