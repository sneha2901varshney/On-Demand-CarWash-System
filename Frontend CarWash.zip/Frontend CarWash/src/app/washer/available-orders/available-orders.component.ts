import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../../core/auth.service';
import { WasherService } from '../../core/washer.service';

interface Order {
  id: number;
  customer: string;
  carModel: string;
  carNumber?: string;
  service: string;
  location?: string;
  status?: string;
  dateCreated?: string;
}

@Component({
  selector: 'app-available-orders',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './available-orders.component.html',
  styleUrls: ['./available-orders.component.css']
})
export class AvailableOrdersComponent implements OnInit {
  orders: Order[] = [];
  washerId: string | number | null = null;

  constructor(
    private washerService: WasherService,
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.fetchWasherId();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) throw new Error('Missing authentication token');

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
  }

  fetchWasherId(): void {
    const token = this.authService.getToken();
    if (!token) {
      console.error('No token found');
      return;
    }

    const email = this.authService.extractEmailFromToken(token);
    const headers = this.getAuthHeaders();

    this.http.get(`http://localhost:8080/api/washers/email/${email}`, { headers }).subscribe({
      next: (response: any) => {
        console.log('Washer data:', response);
        this.washerId = response.id;
        this.fetchOrders(); // Fetch orders after getting washer ID
      },
      error: (error: any) => {
        console.error('Error fetching washer data:', error);
      }
    });
  }

  fetchOrders(): void {
    // Load from localStorage first
    const availableOrders = JSON.parse(localStorage.getItem('availableOrders') || '[]');
    this.orders = availableOrders.filter((order: any) => order.status === 'PENDING');

    // Also try to fetch from API if washerId is available
    if (this.washerId) {
      this.washerService.getCurrentOrders(String(this.washerId)).subscribe({
        next: (data) => {
          // Merge API data with localStorage data
          const apiOrders = data.filter((order: any) => order.status === 'PENDING');
          this.orders = [...this.orders, ...apiOrders];
        },
        error: (err) => {
          console.error('Failed to fetch orders from API:', err);
          // Continue with localStorage data only
        }
      });
    }
  }

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('washerActivities') || '[]');
    activities.unshift(newActivity);
    activities.splice(10);
    localStorage.setItem('washerActivities', JSON.stringify(activities));
  }

  saveOrderToLocalStorage(orderId: number, status: string): void {
    const orderData = {
      id: orderId,
      washerId: this.washerId,
      status: status,
      amount: 500, // Default amount, can be dynamic
      dateUpdated: new Date().toISOString()
    };

    const orders = JSON.parse(localStorage.getItem('washerOrders') || '[]');
    const existingIndex = orders.findIndex((order: any) => order.id === orderId);
    if (existingIndex >= 0) {
      orders[existingIndex] = orderData;
    } else {
      orders.push(orderData);
    }
    localStorage.setItem('washerOrders', JSON.stringify(orders));
  }

  accept(orderId: number): void {
    // Update localStorage immediately
    this.updateOrderStatus(orderId, 'ACCEPTED');
    this.addActivity('order_accepted', `Order #${orderId} accepted`);
    this.saveOrderToLocalStorage(orderId, 'ACCEPTED');
    
    // Try API call
    this.washerService.acceptOrder(orderId).subscribe({
      next: () => {
        this.fetchOrders();
      },
      error: (err) => {
        console.error('API call failed, but localStorage updated:', err);
        this.fetchOrders();
      }
    });
  }

  reject(orderId: number): void {
    // Update localStorage immediately
    this.updateOrderStatus(orderId, 'REJECTED');
    this.addActivity('order_rejected', `Order #${orderId} rejected`);
    
    // Try API call
    this.washerService.declineOrder(orderId).subscribe({
      next: () => {
        this.fetchOrders();
      },
      error: (err) => {
        console.error('API call failed, but localStorage updated:', err);
        this.fetchOrders();
      }
    });
  }

  updateOrderStatus(orderId: number, status: string): void {
    const availableOrders = JSON.parse(localStorage.getItem('availableOrders') || '[]');
    const orderIndex = availableOrders.findIndex((order: any) => order.id === orderId);
    if (orderIndex >= 0) {
      availableOrders[orderIndex].status = status;
      localStorage.setItem('availableOrders', JSON.stringify(availableOrders));
    }
  }
}