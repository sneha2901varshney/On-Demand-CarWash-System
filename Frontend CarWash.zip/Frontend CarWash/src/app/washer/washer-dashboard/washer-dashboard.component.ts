import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { WasherService } from '../../core/washer.service'; // ✅ New

@Component({
  selector: 'app-washer-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './washer-dashboard.component.html',
  styleUrls: ['./washer-dashboard.component.css']
})
export class WasherDashboardComponent implements OnInit {
  isSidebarOpen = true;
  isLargeScreen = window.innerWidth >= 768;
  washerData: any = {};
  washerId: string | number | null = null;
  completedOrders: number = 0;
  activeOrders: number = 0;
  totalEarnings: number = 0;
  recentActivities: any[] = [];

  constructor(
    private authService: AuthService,
    private router: Router,
    private http: HttpClient,
    private washerService: WasherService // ✅ Injected
  ) {}

  @HostListener('window:resize', [])
  onResize() {
    this.isLargeScreen = window.innerWidth >= 768;
    if (this.isLargeScreen) {
      this.isSidebarOpen = true;
    }
  }

  ngOnInit(): void {
    this.fetchWasherData(); // ✅ Load washer info
    this.loadStats();
    this.loadRecentActivities();
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) throw new Error('Missing authentication token');

    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
  }

  fetchWasherData(): void {
    const token = this.authService.getToken();
    if (!token) {
      console.error('No token found');
      return;
    }

    const email = this.authService.extractEmailFromToken(token);
    const headers = this.getAuthHeaders();

    this.http.get(`http://localhost:8080/api/washers/email/${email}`, { headers }).subscribe({
      next: (response: any) => {
        console.log('Washer data:', response);
        this.washerData = response;
        this.washerId = response.id;
        this.washerService.setWasherId(response.id); // ✅ Save ID globally
      },
      error: (error: any) => {
        console.error('Error fetching washer data:', error);
      }
    });
  }

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  loadStats(): void {
    // Load completed orders count
    const orders = JSON.parse(localStorage.getItem('washerOrders') || '[]');
    this.completedOrders = orders.filter((order: any) => order.status === 'COMPLETED').length;
    this.activeOrders = orders.filter((order: any) => order.status === 'IN_PROGRESS' || order.status === 'ACCEPTED').length;
    
    // Calculate total earnings from completed orders
    this.totalEarnings = orders
      .filter((order: any) => order.status === 'COMPLETED')
      .reduce((total: number, order: any) => total + (order.amount || 0), 0);
  }

  loadRecentActivities(): void {
    const activities = JSON.parse(localStorage.getItem('washerActivities') || '[]');
    this.recentActivities = activities.slice(0, 5); // Show only last 5 activities
  }

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('washerActivities') || '[]');
    activities.unshift(newActivity); // Add to beginning
    activities.splice(10); // Keep only last 10 activities
    localStorage.setItem('washerActivities', JSON.stringify(activities));
    this.loadRecentActivities();
  }

  getActivityIcon(type: string): string {
    switch(type) {
      case 'order_completed': return 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z';
      case 'order_accepted': return 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z';
      case 'payment_received': return 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1';
      default: return 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z';
    }
  }

  getActivityColor(type: string): string {
    switch(type) {
      case 'order_completed': return 'green';
      case 'order_accepted': return 'blue';
      case 'payment_received': return 'yellow';
      default: return 'gray';
    }
  }

  getTimeAgo(timestamp: string): string {
    const now = new Date();
    const activityTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - activityTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
