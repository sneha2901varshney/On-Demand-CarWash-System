import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../core/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  handleLogin() {
    console.log('Login clicked');

    if (this.loginForm.invalid) return;

    console.log('Sending login data:', this.loginForm.value);
    this.authService.login(this.loginForm.value).subscribe({
      next: (res: any) => {
        console.log('Login response:', res);

        if (res.token) {
          localStorage.setItem('authToken', res.token);

          const decoded: any = jwtDecode(res.token);
          const role = decoded?.role;

          console.log('User Role:', role);

          if (role === 'Washer') {
            this.router.navigate(['/washer-dashboard']);
          } else if (role === 'Admin') {
            this.router.navigate(['/admin-dashboard']);
          } else if (role === 'Customer') {
            this.router.navigate(['/user-dashboard']);
          } else {
            this.router.navigate(['/login']);
          }
        } else {
          this.errorMessage = res.message || 'Login failed.';
        }
      },
      error: (err) => {
        console.error('Login error:', err);
        this.errorMessage = 'Login failed. Please check your credentials.';
      },
    });
  }
}
