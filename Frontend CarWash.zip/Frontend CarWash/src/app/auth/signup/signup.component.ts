import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../core/auth.service';
 
@Component({

  selector: 'app-signup',

  standalone: true,

  imports: [CommonModule, FormsModule, RouterLink],

  templateUrl: './signup.component.html',

  styleUrls: ['./signup.component.css']

})

export class SignupComponent {

  formData = {
    fullName: '',
    email: '',
    username: '',
    password: '',
    role: ''
  };
  

  selectedRole = ''; // <-- Add this
 
  constructor(private authService: AuthService, private router: Router) {}
 
  onSubmit(): void {
    // Validate form data
    if (!this.formData.fullName || !this.formData.email || !this.formData.username || !this.formData.password || !this.formData.role) {
      alert('Please fill in all required fields');
      return;
    }

    const payload = {
      fullName: this.formData.fullName.trim(),
      email: this.formData.email.trim(),
      username: this.formData.username.trim(),
      password: this.formData.password,
      role: this.formData.role
    };
    
    console.log('Submitting signup with payload:', payload);
 
    this.authService.signup(payload).subscribe({
      next: (response) => {
        console.log('Signup successful:', response);
        alert('Signup successful');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Signup error:', err);
        let errorMessage = 'Signup failed';
        
        if (err.error) {
          if (typeof err.error === 'string') {
            errorMessage += ': ' + err.error;
          } else if (err.error.message) {
            errorMessage += ': ' + err.error.message;
          } else if (err.error.errors) {
            // Handle validation errors
            const errors = Object.values(err.error.errors).flat();
            errorMessage += ': ' + errors.join(', ');
          }
        }
        
        alert(errorMessage);
      }
    });
  }

}

 