import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <!-- Hero Section -->
      <section class="relative py-20 px-6">
        <div class="max-w-7xl mx-auto">
          <div class="text-center mb-16">
            <h1 class="text-5xl lg:text-7xl font-bold text-gray-900 mb-6">
              Premium <span class="text-blue-600">Car Wash</span> Services
            </h1>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Experience the ultimate car care with our professional washing and detailing services. 
              Your vehicle deserves the best treatment.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
              <a routerLink="/signup" class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
                Book Now
              </a>
              <a routerLink="/services" class="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
                View Services
              </a>
            </div>
          </div>
        </div>
      </section>

      <!-- Features Grid -->
      <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
            <p class="text-xl text-gray-600">Professional service with unmatched quality</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div class="text-center p-6 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors">
              <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Fast Service</h3>
              <p class="text-gray-600">Quick and efficient washing in under 30 minutes</p>
            </div>
            <div class="text-center p-6 rounded-xl bg-green-50 hover:bg-green-100 transition-colors">
              <div class="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Quality Assured</h3>
              <p class="text-gray-600">100% satisfaction guarantee on all services</p>
            </div>
            <div class="text-center p-6 rounded-xl bg-purple-50 hover:bg-purple-100 transition-colors">
              <div class="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Mobile Service</h3>
              <p class="text-gray-600">We come to your location for convenience</p>
            </div>
            <div class="text-center p-6 rounded-xl bg-orange-50 hover:bg-orange-100 transition-colors">
              <div class="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Affordable</h3>
              <p class="text-gray-600">Competitive pricing with great value</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Services Preview -->
      <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Service Packages</h2>
            <p class="text-xl text-gray-600">Choose from our range of professional car care services</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Essential Care</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹500</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Exterior wash</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Tire & Rim cleaning</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Professional Drying</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Basic interior wipe</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border-2 border-blue-500">
              <div class="text-center mb-4">
                <span class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-semibold">Most Popular</span>
              </div>
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Complete Detail</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹1000</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Everything in Essential</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Interior vacuuming</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Dashboard & Console Care</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Window cleaning(Inside & Out)</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Premium Detail</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹1500</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Everything in Complete</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Paint Protection Wax</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Leather Treatment</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Engine Bay Cleaning</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
          </div>
        </div>
      </section>

      
      <!-- CTA Section -->
      <section class="py-20 bg-blue-600">
        <div class="max-w-4xl mx-auto px-6 text-center">
          <h2 class="text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
          <p class="text-xl text-blue-100 mb-8">
            Book your car wash service today and experience the difference professional care makes.
          </p>
          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a routerLink="/signup" class="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
              Book Service Now
            </a>
            <a href="tel:+91-XXXX-XXXXX" class="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
              Call Us
            </a>
          </div>
        </div>
      </section>
    </div>
  `
})
export class HomeComponent { }