import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-white">
      <!-- Hero Section -->
      <section class="py-20 bg-gradient-to-br from-blue-50 to-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h1 class="text-5xl font-bold text-gray-900 mb-6">About EcoLuxe Elite Auto Lounge</h1>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">
              We are passionate about providing premium automotive care services that exceed expectations. 
              Our commitment to excellence and customer satisfaction drives everything we do.
            </p>
          </div>
        </div>
      </section>

      <!-- Our Story Section -->
      <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 class="text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p class="text-lg text-gray-600 mb-6">
                Founded with a vision to revolutionize the car care industry, EcoLuxe Elite Auto Lounge has been 
                serving customers with dedication and expertise for over a decade. We believe that every vehicle 
                deserves the highest quality care and attention.
              </p>
              <p class="text-lg text-gray-600 mb-6">
                Our team of certified professionals uses state-of-the-art equipment and eco-friendly products 
                to ensure your vehicle receives the best possible treatment while protecting the environment.
              </p>
              <div class="flex items-center space-x-8">
                <div class="text-center">
                  <div class="text-3xl font-bold text-blue-600">10+</div>
                  <div class="text-sm text-gray-600">Years Experience</div>
                </div>
                <div class="text-center">
                  <div class="text-3xl font-bold text-blue-600">50K+</div>
                  <div class="text-sm text-gray-600">Happy Customers</div>
                </div>
                <div class="text-center">
                  <div class="text-3xl font-bold text-blue-600">100%</div>
                  <div class="text-sm text-gray-600">Satisfaction Rate</div>
                </div>
              </div>
            </div>
            <div class="relative">
              <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                   alt="Car wash facility" 
                   class="rounded-2xl shadow-2xl w-full h-[400px] object-cover">
            </div>
          </div>
        </div>
      </section>

      <!-- How It Works Section -->
      <section class="py-12 bg-gray-50">
        <div class="max-w-6xl mx-auto px-6">
          <div class="mb-8">
            <div class="w-16 h-1 bg-red-500 mb-4"></div>
            <h2 class="text-3xl font-bold text-gray-900 mb-2">How EcoLuxe Elite works?</h2>
          </div>
          
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <!-- Step 1 -->
            <div class="text-center">
              <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-xl font-bold text-gray-600 mx-auto mb-3">
                1
              </div>
              <h3 class="text-lg font-bold text-gray-900 mb-2">Select The Perfect Car Service</h3>
              <p class="text-sm text-gray-600">
                From EcoLuxe Elite's broad portfolio of services
              </p>
            </div>

            <!-- Step 2 -->
            <div class="text-center">
              <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-xl font-bold text-gray-600 mx-auto mb-3">
                2
              </div>
              <h3 class="text-lg font-bold text-gray-900 mb-2">Schedule Free Doorstep Pick-up</h3>
              <p class="text-sm text-gray-600">
                We offer free pick up and drop for all services booked
              </p>
            </div>

            <!-- Step 3 -->
            <div class="text-center">
              <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-xl font-bold text-gray-600 mx-auto mb-3">
                3
              </div>
              <h3 class="text-lg font-bold text-gray-900 mb-2">Track Your Car Service Real-Time</h3>
              <p class="text-sm text-gray-600">
                We will take care of everything from here!
              </p>
            </div>

            <!-- Step 4 -->
            <div class="text-center">
              <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-xl font-bold text-gray-600 mx-auto mb-3">
                4
              </div>
              <h3 class="text-lg font-bold text-gray-900 mb-2">Earn While We Service</h3>
              <p class="text-sm text-gray-600">
                Spread the word! You get Rs.750. Your friends get Rs.750!
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- Our Values Section -->
      <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p class="text-xl text-gray-600">The principles that guide everything we do</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="text-center p-8 rounded-xl bg-blue-50 hover:bg-blue-100 transition-colors">
              <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-3">Quality Excellence</h3>
              <p class="text-gray-600">We never compromise on quality and always strive for perfection in every service we provide.</p>
            </div>
            <div class="text-center p-8 rounded-xl bg-green-50 hover:bg-green-100 transition-colors">
              <div class="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-3">Customer Care</h3>
              <p class="text-gray-600">Our customers are at the heart of everything we do. Their satisfaction is our top priority.</p>
            </div>
            <div class="text-center p-8 rounded-xl bg-purple-50 hover:bg-purple-100 transition-colors">
              <div class="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9v-9m0-9v9"></path>
                </svg>
              </div>
              <h3 class="text-xl font-semibold text-gray-900 mb-3">Environmental Responsibility</h3>
              <p class="text-gray-600">We use eco-friendly products and sustainable practices to protect our planet for future generations.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- Team Section -->
      <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p class="text-xl text-gray-600">The professionals behind our exceptional service</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white p-8 rounded-xl shadow-lg text-center">
              <div class="w-24 h-24 bg-gray-300 rounded-full mx-auto mb-6"></div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Sneha Varshney</h3>
              <p class="text-blue-600 mb-3">Founder & CEO</p>
              <p class="text-gray-600">Leading the company with vision and passion for automotive excellence.</p>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg text-center">
              <div class="w-24 h-24 bg-gray-300 rounded-full mx-auto mb-6"></div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Rashmi Varshney</h3>
              <p class="text-blue-600 mb-3">Operations Manager</p>
              <p class="text-gray-600">Ensuring smooth operations and maintaining our high service standards.</p>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg text-center">
              <div class="w-24 h-24 bg-gray-300 rounded-full mx-auto mb-6"></div>
              <h3 class="text-xl font-semibold text-gray-900 mb-2">Pawan Varshney</h3>
              <p class="text-blue-600 mb-3">Lead Technician</p>
              <p class="text-gray-600">Expert in automotive care with over 15 years of hands-on experience.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- CTA Section -->
      <section class="py-20 bg-blue-600">
        <div class="max-w-4xl mx-auto px-6 text-center">
          <h2 class="text-4xl font-bold text-white mb-6">Ready to Experience Our Service?</h2>
          <p class="text-xl text-blue-100 mb-8">
            Join thousands of satisfied customers who trust us with their vehicles.
          </p>
          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a routerLink="/signup" class="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
              Get Started Today
            </a>
            <a href="tel:+91-XXXX-XXXXX" class="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg transition-colors">
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  `
})
export class AboutComponent { }