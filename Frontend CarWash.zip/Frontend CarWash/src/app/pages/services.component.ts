import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <!-- Hero Section -->
      <section class="py-20 px-6">
        <div class="max-w-7xl mx-auto text-center">
          <h1 class="text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Our <span class="text-blue-600">Services</span>
          </h1>
          <p class="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Comprehensive automotive care services designed to keep your vehicle in perfect condition. 
            From basic maintenance to premium detailing, we've got you covered.
          </p>
        </div>
      </section>

      <!-- Service Packages Section -->
      <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Service Packages</h2>
            <p class="text-xl text-gray-600">Choose from our range of professional car care services</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Essential Care</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹500</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Exterior wash</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Tire & Rim cleaning</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Professional Drying</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Basic interior wipe</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border-2 border-blue-500">
              <div class="text-center mb-4">
                <span class="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-semibold">Most Popular</span>
              </div>
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Complete Detail</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹1000</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Everything in Essential</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Interior vacuuming</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Dashboard & Console Care</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Window cleaning(Inside & Out)</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
            <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <h3 class="text-2xl font-bold text-gray-900 mb-4">Premium Detail</h3>
              <div class="text-3xl font-bold text-blue-600 mb-4">₹1500</div>
              <ul class="space-y-2 text-gray-600 mb-6">
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Everything in Complete</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Paint Protection Wax</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Leather Treatment</li>
                <li class="flex items-center"><span class="text-green-500 mr-2">✓</span>Engine Bay Cleaning</li>
              </ul>
              <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-colors">
                Choose Plan
              </button>
            </div>
          </div>
        </div>
      </section>

      <!-- Car Services Section -->
      <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-6">
          <div class="mb-12">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Car Services Available</h2>
            <p class="text-lg text-gray-600 max-w-4xl">
              Choose from a wide assortment of car services from periodic car servicing, car care services, wheel care services, cashless insurance claims and much more!
            </p>
          </div>
          
          <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Periodic Services</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">AC Service & Repair</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Batteries</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-purple-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-purple-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Tyres & Wheel Care</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Denting & Painting</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-teal-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-teal-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Detailing Services</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-pink-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-pink-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Car Spa & Cleaning</h3>
            </div>

            <div class="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
              <div class="w-16 h-16 mx-auto mb-4 bg-indigo-100 rounded-full flex items-center justify-center">
                <svg class="w-10 h-10 text-indigo-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/>
                </svg>
              </div>
              <h3 class="text-lg font-semibold text-gray-800">Insurance Claims</h3>
            </div>
          </div>
        </div>
      </section>

      <!-- Price List Section -->
      <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-6">
          <div class="text-center mb-12">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Car Services Price List in EcoLuxe, India 2025</h2>
            <p class="text-lg text-gray-600">Transparent pricing for all our professional car care services</p>
          </div>
          
          <div class="overflow-x-auto shadow-lg rounded-lg">
            <table class="w-full bg-white">
              <thead class="bg-gray-100">
                <tr>
                  <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 border-b">Services Type</th>
                  <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 border-b">Price Starts From (₹)</th>
                  <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700 border-b">Savings</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-200">
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Car Inspection/Diagnostics</td>
                  <td class="px-6 py-4 text-gray-800">499</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">15%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Inspection</td>
                  <td class="px-6 py-4 text-gray-800">499</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">25%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Door Glass Replacement</td>
                  <td class="px-6 py-4 text-gray-800">850</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">30%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Wind Shield Replacement(Insurance)</td>
                  <td class="px-6 py-4 text-gray-800">1000</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">25%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Accessories</td>
                  <td class="px-6 py-4 text-gray-800">1099</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">30%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Regular AC Service</td>
                  <td class="px-6 py-4 text-gray-800">1299</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">15%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Front Head Lights</td>
                  <td class="px-6 py-4 text-gray-800">1399</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">30%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Tyres & Wheel Care</td>
                  <td class="px-6 py-4 text-gray-800">1890</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">25%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Basic Service</td>
                  <td class="px-6 py-4 text-gray-800">2099</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">10%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Batteries</td>
                  <td class="px-6 py-4 text-gray-800">3199</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">15%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Ceramic Coating</td>
                  <td class="px-6 py-4 text-gray-800">14999</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">25%</td>
                </tr>
                <tr class="hover:bg-gray-50">
                  <td class="px-6 py-4 text-gray-800">Full Body Dent Paint</td>
                  <td class="px-6 py-4 text-gray-800">23000</td>
                  <td class="px-6 py-4 text-green-600 font-semibold">15%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  `
})
export class ServicesComponent {
}