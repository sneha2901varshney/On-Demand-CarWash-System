  import { Component, OnInit } from '@angular/core';
  import { NgIf, NgFor, NgClass } from '@angular/common';
  import { FormsModule } from '@angular/forms';
  import { Washer, WasherInputDto, WasherService } from './washer.service';

  @Component({
    selector: 'app-manage-washers',
    templateUrl: './manage-washers.component.html',
    standalone: true,
    imports: [
      NgIf,
      NgFor,
      FormsModule
  ]
  })
  export class ManageWashersComponent implements OnInit {
    washers: Washer[] = [];
    loading = false;
    error: string | null = null;

    
  newWasher: WasherInputDto = {
    fullName: '',   
    email: '',
    phone: '',
    password: ''
  };
  

    constructor(private washerService: WasherService) {}

    ngOnInit(): void {
      this.fetchWashers();
    }

    fetchWashers(): void {
      this.loading = true;
      this.washerService.getAllWashers().subscribe({
        next: (res) => {
          this.washers = Array.isArray(res) ? res : [];
          this.loading = false;
        },
        error: () => {
          this.error = 'Failed to load washers';
          this.loading = false;
          this.washers = [];
        }
      });
    }

    addWasher(): void {
      this.washerService.addOrEditWasher(this.newWasher).subscribe({
        next: () => {
          this.fetchWashers();
          this.newWasher = { fullName: '', email: '', phone: '', password: '' };

        },
        error: () => this.error = 'Failed to add washer'
      });
    }

    deleteWasher(id: number): void {
      if (!confirm('Are you sure you want to delete this washer?')) return;
    
      this.washerService.deleteWasher(id.toString()).subscribe({
        next: () => this.fetchWashers(),
        error: () => this.error = 'Failed to delete washer'
      });
    }
    updateWasher(washer: Washer): void {
      if (washer.phone === null) {
        this.error = 'Phone number cannot be null';
        return;
      }
      this.washerService.addOrEditWasher({ ...washer, phone: washer.phone }).subscribe({
        next: () => this.fetchWashers(),
        error: () => this.error = 'Failed to update washer'
      });
    }    
  }
