export interface Order {
  id: number;
  customerId: number;
  washerId: number;
  carModel: string;
  carNumber: string;
  carName: string;
  packageName: string;
  addOns: string;
  status: string;
  washDate: string;
  scheduleDate: string;
  location: string;
  paymentStatus: string;
  price: number;
}
