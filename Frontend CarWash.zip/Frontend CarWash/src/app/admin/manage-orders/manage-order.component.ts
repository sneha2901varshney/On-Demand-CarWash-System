import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';

@Component({
  standalone: true,
  selector: 'app-manage-orders',
  imports: [CommonModule, HttpClientModule],
  templateUrl: './manage-orders.component.html'
  
})
export class ManageOrdersComponent implements OnInit {
  orders: any[] = [];
  apiUrl = 'http://localhost:8080/api/admin/orders'; // replace with actual URL

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.getAllOrders();
  }

  private getAuthHeaders(): HttpHeaders {
      const token = localStorage.getItem('authToken');
      if (!token) {
        throw new Error('Missing authentication token');
      }
      return new HttpHeaders({
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      });
    }

  getAllOrders(): void {
    const headers = this.getAuthHeaders();
    this.http.get<any>(this.apiUrl,{headers}).subscribe({
      next: (res) => {
        this.orders = res || [];
      },
      error: (err) => {
        console.error('Failed to fetch orders', err);
      }
    });
  }
}
