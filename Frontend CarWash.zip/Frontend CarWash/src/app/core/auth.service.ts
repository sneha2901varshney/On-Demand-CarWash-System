// // auth.service.ts
// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   private baseUrl = 'https://localhost:7266/api/Account'; // ✅ CORRECT (from launchSettings.json)

//   constructor(private http: HttpClient) {}

//   login(data: any) {
//     return this.http.post(`${this.baseUrl}/Login`, data);
//   }

//   signup(data: any) {
//     return this.http.post(`${this.baseUrl}/Register`, data);
//   }
// }

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'http://localhost:8080/auth';

  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http.post(`${this.baseUrl}/login`, data).pipe(
      catchError(this.handleError)
    );
  }

  signup(data: any) {
    console.log('Signup payload:', JSON.stringify(data, null, 2));
    return this.http.post(`${this.baseUrl}/register`, data).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error('HTTP Error:', error);
    console.error('Status:', error.status);
    console.error('Message:', error.message);
    console.error('Error body:', error.error);
    
    // Log more details for debugging
    if (error.error) {
      console.error('Detailed error:', JSON.stringify(error.error, null, 2));
    }
    
    return throwError(() => error);
  }

  logout() {
    localStorage.removeItem('authToken');
  }

  // ✅ Returns the JWT token from local storage
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  // ✅ Decodes and returns the user role from JWT
  getUserRole(): string | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const decoded: any = jwtDecode(token);
      return decoded?.role || null;
    } catch {
      return null;
    }
  }

  extractEmailFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.sub || null;
    } catch (e) {
      console.error('Failed to decode token', e);
      return null;
    }
  }
  
}
