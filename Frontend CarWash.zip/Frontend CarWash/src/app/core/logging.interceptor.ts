import { HttpInterceptorFn } from '@angular/common/http';
import { tap } from 'rxjs';

export const loggingInterceptor: HttpInterceptorFn = (req, next) => {
  console.log('🚀 HTTP Request:', req.method, req.url);
  console.log('📤 Request body:', req.body);
  
  return next(req).pipe(
    tap({
      next: (response) => {
        console.log('✅ HTTP Response:', response);
      },
      error: (error) => {
        console.error('❌ HTTP Error:', error);
        console.error('Status:', error.status);
        console.error('URL:', req.url);
        console.error('Method:', req.method);
        console.error('Error details:', error.error);
      }
    })
  );
};