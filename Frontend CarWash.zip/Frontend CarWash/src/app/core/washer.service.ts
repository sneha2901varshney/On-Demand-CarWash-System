import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class WasherService {

  private washerId: string | number | null = null;

  setWasherId(id: string | number) {
    this.washerId = id;
  }

  getWasherId(): string | number | null {
    return this.washerId;
  }
  private baseUrl = 'http://localhost:8080/api/washers'; // update if needed

  private authHeaders = () => ({
    headers: new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('authToken')}`,
      'Content-Type': 'application/json',
    })
  });

  constructor(private http: HttpClient) {}

  // ✅ NEW: Fetch washer by email
  getWasherByEmail(email: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/email/${email}`, this.authHeaders());
  }

  getProfile(washerId: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${washerId}`, this.authHeaders());
  }

  updateProfile(washerId: string, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${washerId}`, data, this.authHeaders());
  }

  getCurrentOrders(washerId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/${washerId}/orders/current`, this.authHeaders());
  }

  getPastOrders(washerId: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/${washerId}/orders/past`, this.authHeaders());
  }

  getReviews(washerId: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/reviews/washer/${washerId}`, this.authHeaders());
  }

  acceptOrder(orderId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/orders/${orderId}/accept`, {}, this.authHeaders());
  }

  declineOrder(orderId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/orders/${orderId}/decline`, {}, this.authHeaders());
  }

  updateOrderStatus(orderId: number, status: string, imageUrl?: string): Observable<any> {
    const payload = { status, imageUrl };
    return this.http.put(`${this.baseUrl}/orders/${orderId}/status`, payload, this.authHeaders());
  }

  // If invoice support is needed later
  // getInvoices(washerId: string): Observable<any> {
  //   return this.http.get(`${this.invoiceUrl}/washer/${washerId}`, this.authHeaders());
  // }
}
