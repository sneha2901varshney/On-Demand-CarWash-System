import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@Component({
  selector: 'app-review',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  reviewForm!: FormGroup;
  customerReviews: any[] = [];
  washerReviews: any[] = [];
  customerId = 1;
  washerId = 1;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.reviewForm = this.fb.group({
      rating: [5, [Validators.required, Validators.min(1), Validators.max(5)]],
      comment: ['', Validators.required]
    });

    this.getCustomerReviews();
    this.getWasherReviews();
  }

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('recentActivities') || '[]');
    activities.unshift(newActivity);
    activities.splice(10);
    localStorage.setItem('recentActivities', JSON.stringify(activities));
  }

  submitReview(): void {
    if (this.reviewForm.valid) {
      const newReview = {
        id: Date.now(),
        customerId: this.customerId,
        washerId: this.washerId,
        rating: this.reviewForm.value.rating,
        comment: this.reviewForm.value.comment,
        date: new Date().toLocaleDateString()
      };

      // Save to localStorage
      const existingReviews = JSON.parse(localStorage.getItem('customerReviews') || '[]');
      existingReviews.push(newReview);
      localStorage.setItem('customerReviews', JSON.stringify(existingReviews));

      // Add activity
      this.addActivity('review', `Review submitted with ${this.reviewForm.value.rating} stars`);

      // Reset form and refresh reviews
      this.reviewForm.reset({ rating: 5, comment: '' });
      this.getCustomerReviews();
      alert('Review submitted successfully!');
    }
  }

  getCustomerReviews(): void {
    const reviews = JSON.parse(localStorage.getItem('customerReviews') || '[]');
    this.customerReviews = reviews.filter((review: any) => review.customerId === this.customerId);
  }

  getWasherReviews(): void {
    // Sample washer reviews for display
    this.washerReviews = [
      { id: 1, rating: 5, comment: 'Excellent service! Very professional and thorough.', date: '2024-01-15' },
      { id: 2, rating: 4, comment: 'Good job, car looks great. Will use again.', date: '2024-01-10' },
      { id: 3, rating: 5, comment: 'Amazing work! Best car wash service in town.', date: '2024-01-05' }
    ];
  }
}