import { Component, HostListener, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CustomerService } from '../../core/customer.service';


@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  isSidebarOpen = true;
  isLargeScreen = window.innerWidth >= 768;
  userData: any ={};
  recentActivities: any[] = [];
  totalCars: number = 0;
  completedOrders: number = 0;
  reviewsGiven: number = 0;

  constructor(private authService: AuthService, private router: Router,private http: HttpClient, private customerService: CustomerService) {}


  customerId : String | number | null = null;

  @HostListener('window:resize', [])
  onResize() {
    this.isLargeScreen = window.innerWidth >= 768;
    if (this.isLargeScreen) {
      this.isSidebarOpen = true;
    }
  }

  ngOnInit(): void {
    // Load dealer data first
    this.fetchCustomerData();
    this.loadRecentActivities();
    this.loadStats();
 
    // Slight delay to ensure dealer data is loaded before other operations
    // setTimeout(() => {
    //   this.fetchAllCrops();
    //   this.fetchMyOrders();
    // }, 500);
 
    // Existing initialization code
    // this.fetchDealerData();
    // this.fetchAllCrops();// Add this to load cart on component initialization
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    if (!token) {
      throw new Error('Missing authentication token');
    }
    return new HttpHeaders({
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    });
  }
 
 
  fetchCustomerData(): void {
    console.log('Fetching dealer data to get ID');
    const token = this.authService.getToken();
console.log('Token:', token);
if (!token) {
  console.error('No token found');
  return;
}


 
    const email = this.authService.extractEmailFromToken(token);
 
    // Direct API call to get dealer ID by email
    const headers = this.getAuthHeaders();
    this.http.get(`http://localhost:8080/api/customers/email/${email}`,{headers}).subscribe({
      

      next: (response: any) => {
        
        console.log('Customer data response:', response);
        // Store just the dealer ID
        this.customerId = response.id;
        this.customerService.setCustomerId(response.id);  // 🔥 Save it here
        console.log('Customer ID set to:', this.customerId);
 
        // Also store the full user data
        this.userData = response;
      },
      error: (error: any) => {
        console.error('Error fetching Customer ID:', error);
      }
    });
  }
 
  // fetchAllCrops(): void {
  //   // This is the API call to get all crops from farmers
  //   this.http.get('/api/dealer/crops').subscribe(
  //     (crops: any) => {
  //       console.log('Fetched available crops:', crops);
  //       this.availableCrops = crops;
  //     },
  //     (error) => {
  //       console.error('Error fetching crops:', error);
  //     }
  //   );
  // }
 
  // fetchMyOrders(): void {
  //   if (!this.dealerId) {
  //     console.error('Cannot fetch orders: Missing dealer ID');
  //     return;
  //   }
 
  //   console.log('Fetching cart items for orders display, dealer ID:', this.dealerId);
 
  //   this.http.get(`/api/dealer/dealer/${this.dealerId}`).subscribe({
  //     next: (response: any) => {
  //       console.log('Cart data fetched for orders:', response);
 
  //       // Process the cart items to match orders format
  //       if (Array.isArray(response)) {
  //         this.myOrders = response.map(item => ({
  //           id: item.id || item.cropId || 'N/A',
  //           crop: item.cropName || 'Unknown Crop',
  //           quantity: item.quantity || 0,
  //           totalPrice: (item.pricePerKg * item.quantity) || 0,
  //           price: item.pricePerKg || 0,
  //           seller: item.farmerName || 'Unknown Farmer',
  //           date: new Date().toLocaleDateString(),
  //           status: 'In Cart'
  //         }));
  //       } else {
  //         console.warn('Cart response is not an array:', response);
  //         this.myOrders = [];
  //       }
 
  //       console.log('Processed orders for display:', this.myOrders);
  //     },
  //     error: (error) => {
  //       console.error('Error fetching cart for orders:', error);
  //       this.myOrders = [];
  //     }
  //   });
  // }

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  loadRecentActivities(): void {
    const activities = JSON.parse(localStorage.getItem('recentActivities') || '[]');
    this.recentActivities = activities.slice(0, 5); // Show only last 5 activities
  }

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('recentActivities') || '[]');
    activities.unshift(newActivity); // Add to beginning
    activities.splice(10); // Keep only last 10 activities
    localStorage.setItem('recentActivities', JSON.stringify(activities));
    this.loadRecentActivities();
  }

  getActivityIcon(type: string): string {
    switch(type) {
      case 'car': return 'M12 4v16m8-8H4';
      case 'order': return 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z';
      case 'review': return 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z';
      default: return 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z';
    }
  }

  getActivityColor(type: string): string {
    switch(type) {
      case 'car': return 'green';
      case 'order': return 'blue';
      case 'review': return 'yellow';
      default: return 'gray';
    }
  }

  loadStats(): void {
    // Load cars count from localStorage or API
    const cars = JSON.parse(localStorage.getItem('userCars') || '[]');
    this.totalCars = cars.length;

    // Load completed orders count
    const orders = JSON.parse(localStorage.getItem('userOrders') || '[]');
    this.completedOrders = orders.filter((order: any) => order.status === 'COMPLETED').length;

    // Load reviews count
    const reviews = JSON.parse(localStorage.getItem('customerReviews') || '[]');
    this.reviewsGiven = reviews.length;
  }

  getTimeAgo(timestamp: string): string {
    const now = new Date();
    const activityTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - activityTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}