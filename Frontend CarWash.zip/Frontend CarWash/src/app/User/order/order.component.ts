import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OrderService } from './order.service';
import { HttpErrorResponse } from '@angular/common/http';
import { CustomerService } from '../../core/customer.service'; // adjust path as needed

@Component({
  standalone: true,
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  imports: [CommonModule, FormsModule]
})
export class OrderComponent implements OnInit {

  orderData = {
    id: 0,
    customerId: 0,
    washerId: 0,
    carModel: '',
    carNumber: '',
    carName: '',
    packageName: '',
    addOns: '',
    status: '',
    washDate: '',
    scheduleDate: '',
    location: ''
  };

  pastOrders: any[] = [];
  currentOrders: any[] = [];
  isLoading = false;

  constructor(private orderService: OrderService, private customerService: CustomerService) {}

  ngOnInit(): void {
    const id = this.customerService.getCustomerId();
    if (id) {
      this.orderData.customerId = id;
    } else {
      console.warn('⚠️ Customer ID not found.');
    }
  }

  private get currentCustomerId(): string | null {
    const id = this.customerService.getCustomerId();
    return id !== null && id !== undefined ? id.toString() : null;
  }
  

  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('recentActivities') || '[]');
    activities.unshift(newActivity);
    activities.splice(10);
    localStorage.setItem('recentActivities', JSON.stringify(activities));
  }

  saveOrderToLocalStorage(): void {
    const orderData = {
      id: Date.now(),
      customerId: this.orderData.customerId,
      carName: this.orderData.carName,
      carModel: this.orderData.carModel,
      carNumber: this.orderData.carNumber,
      packageName: this.orderData.packageName,
      location: this.orderData.location,
      status: 'PENDING',
      dateCreated: new Date().toISOString()
    };

    // Save to user orders
    const userOrders = JSON.parse(localStorage.getItem('userOrders') || '[]');
    userOrders.push(orderData);
    localStorage.setItem('userOrders', JSON.stringify(userOrders));

    // Save to available orders for washers
    const availableOrders = JSON.parse(localStorage.getItem('availableOrders') || '[]');
    availableOrders.push({
      id: orderData.id,
      customer: `Customer #${this.orderData.customerId}`,
      carModel: this.orderData.carModel || this.orderData.carName,
      carNumber: this.orderData.carNumber,
      service: this.orderData.packageName,
      location: this.orderData.location,
      status: 'PENDING',
      dateCreated: new Date().toISOString()
    });
    localStorage.setItem('availableOrders', JSON.stringify(availableOrders));
  }

  createOrder(): void {
    const customerId = this.currentCustomerId;
    if (!customerId) {
      alert('⚠️ Customer ID not found. Please login.');
      return;
    }
    this.orderData.customerId = Number(customerId);
    // Set default status here, e.g., "PENDING"
  this.orderData.status = 'PENDING';
  
    this.isLoading = true;
    console.log('Submitting order:', this.orderData);
    this.orderService.createOrder(this.orderData).subscribe({
      next: (res) => {
        console.log('Order Created:', res);
        alert('✅ Order successfully created!');
        this.addActivity('order', `New order placed: ${this.orderData.packageName} for ${this.orderData.carName}`);
        this.saveOrderToLocalStorage();
        // You must ensure the created order ID is returned
    if (res && res.id) {
      alert('✅ Order created! Redirecting to payment...');
      this.initiatePayment(res.id);
    } else {
      alert('✅ Order created, but no ID received.');
    }
        this.resetOrderForm();
      },
      error: (err: HttpErrorResponse) => {
        console.error('❌ Error creating order:', err);
        if (err.status === 401) {
          alert('⚠️ Unauthorized! Please login again.');
        } else {
          alert('❌ Failed to create order. Please try again.');
        }
      },
      complete: () => this.isLoading = false
    });
  }

  initiatePayment(orderId: number): void {
    const customerId = this.currentCustomerId;
    if (!customerId) {
      alert('⚠️ Customer ID not found. Please login.');
      return;
    }
  
    const paymentPayload = {
      orderId: orderId.toString(),
      customerId: customerId
    };
  
    this.orderService.createPaymentIntent(paymentPayload).subscribe({
      next: (res: any) => {
        if (res.sessionUrl) {
          console.log('✅ Payment session created. Redirecting...');
          window.location.href = res.sessionUrl;  // This is actually the session URL
        } else {
          alert('⚠️ Payment URL not received.');
        }
      },
      error: (err) => {
        console.error('❌ Error creating payment intent:', err);
        alert('Failed to start payment. Try again later.');
      }
    });
  }
  

  fetchPastOrders(): void {
    const customerId = this.currentCustomerId;
    if (!customerId) {
      alert('⚠️ Customer ID not found. Please login.');
      return;
    }
    this.orderService.getPastOrders(customerId).subscribe({
      next: (data) => {
        this.pastOrders = data;
        if (!data || data.length === 0) {
          alert('ℹ️ No past orders found for this customer.');
        }
      },
      error: (err) => {
        console.error('Error fetching past orders:', err);
        alert('❌ Could not fetch past orders.');
      }
    });
  }

  fetchCurrentOrders(): void {
    const customerId = this.currentCustomerId;
    if (!customerId) {
      alert('⚠️ Customer ID not found. Please login.');
      return;
    }
    this.orderService.getCurrentOrders(customerId).subscribe({
      next: (data) => {
        this.currentOrders = data;
        if (!data || data.length === 0) {
          alert('ℹ️ No current orders found for this customer.');
        }
      },
      error: (err) => {
        console.error('Error fetching current orders:', err);
        alert('❌ Could not fetch current orders.');
      }
    });
  }

  resetOrderForm(): void {
    this.orderData = {
      id: 0,
      customerId: this.orderData.customerId, // keep existing customerId
      washerId: 0,
      carModel: '',
      carNumber: '',
      carName: '',
      packageName: '',
      addOns: '',
      status: '',
      washDate: '',
      scheduleDate: '',
      location: ''
    };
  }
}
