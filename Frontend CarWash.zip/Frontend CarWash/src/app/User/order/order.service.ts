import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private baseUrl = 'http://localhost:8080/api/customers/orders';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  createOrder(order: any): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.post(`${this.baseUrl}/create`, order, { headers });
  }

  createPaymentIntent(data: { orderId: string; customerId: string }) {
    return this.http.post<{ clientSecret: string }>(
      'http://localhost:8085/api/payments/create-payment-intent',
      data
    );
  }
  getOrderById(orderId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.baseUrl}/${orderId}`, { headers });
  }  

  getPastOrders(customerId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.baseUrl}/past/${customerId}`, { headers });
  }

  getCurrentOrders(customerId: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.get(`${this.baseUrl}/current/${customerId}`, { headers });
  }
}
