
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CarService } from '../../core/car.service';
import { CustomerService } from '../../core/customer.service';


@Component({
  selector: 'app-add-customer-car',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-car.component.html',
  styleUrls: ['./add-car.component.css']
})
export class AddCarComponent {
  carForm: FormGroup;
  message = '';
  error = '';

  constructor(private fb: FormBuilder, private http: HttpClient, private customerService: CustomerService  ) {
    const customerId = this.customerService.getCustomerId();
    this.carForm = this.fb.group({
      brand: ['', Validators.required],
      model: ['', Validators.required],
      color: ['', Validators.required],
      licensePlate: ['', [Validators.required, Validators.pattern('^[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}$')]],
      customerId: [customerId, [Validators.required, Validators.min(1)]]
    });
  }


  addActivity(type: string, message: string): void {
    const newActivity = {
      id: Date.now(),
      type: type,
      message: message,
      timestamp: new Date().toISOString(),
      timeAgo: 'Just now'
    };

    const activities = JSON.parse(localStorage.getItem('recentActivities') || '[]');
    activities.unshift(newActivity);
    activities.splice(10);
    localStorage.setItem('recentActivities', JSON.stringify(activities));
  }

  saveCarToLocalStorage(): void {
    const carData = {
      id: Date.now(),
      brand: this.carForm.value.brand,
      model: this.carForm.value.model,
      color: this.carForm.value.color,
      licensePlate: this.carForm.value.licensePlate,
      customerId: this.carForm.value.customerId,
      dateAdded: new Date().toISOString()
    };

    const cars = JSON.parse(localStorage.getItem('userCars') || '[]');
    cars.push(carData);
    localStorage.setItem('userCars', JSON.stringify(cars));
  }

  submit() {
    if (this.carForm.invalid) return;
  
    const customerId = this.customerService.getCustomerId();
    if (!customerId) {
      this.error = 'Customer ID is missing.';
      return;
    }
  
    this.carForm.patchValue({ customerId });
  
    const token = localStorage.getItem('authToken');
    if (!token) {
      this.error = 'User is not logged in.';
      return;
    }
  
    const headers = { Authorization: `Bearer ${token}` };
    const carBrand = this.carForm.value.brand;
    const carModel = this.carForm.value.model;
  
    this.http.post('http://localhost:8080/api/customers/cars', this.carForm.value, { headers }).subscribe({
      next: () => {
        this.message = 'Car added successfully!';
        this.error = '';
        this.addActivity('car', `New car added: ${carBrand} ${carModel}`);
        this.saveCarToLocalStorage();
        this.carForm.reset();
      },
      error: (err) => {
        console.error(err);
        this.message = '';
        this.error = err?.error?.message || 'Failed to add car.';
      }
    });
  }
  
  
  
}
