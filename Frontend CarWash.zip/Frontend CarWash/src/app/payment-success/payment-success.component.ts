import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-success.component.html',
  styleUrl: './payment-success.component.css',
  providers: [DatePipe]
})

export class PaymentSuccessComponent implements OnInit {
  paymentInfo: any;
  isLoading = true;
  error: string | null = null;

  constructor(private route: ActivatedRoute, private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const sessionId = this.route.snapshot.queryParamMap.get('session_id');
    if (sessionId) {
      this.http.get(`http://localhost:8085/api/payments/payment-success?session_id=${sessionId}`)
        .subscribe({
          next: (data) => {
            this.paymentInfo = data;
            this.isLoading = false;
          },
          error: (err) => {
            this.error = 'Payment not found or already processed.';
            this.isLoading = false;
          }
        });
    } else {
      this.error = 'Missing session ID in URL.';
      this.isLoading = false;
    }
  }

  returnToDashboard(): void {
    this.router.navigate(['/user-dashboard']);
  }
}
