# CarWash Angular Application - GenAI Development Prompts

## Project Overview
This Angular 18.2.19 CarWash management system features a multi-role architecture with Customer, Admin, and Washer interfaces. Built with standalone components, Tailwind CSS, and JWT authentication.

## Master Context Prompt
```
You are developing an Angular 18.2.19 CarWash management application with the following specifications:

**Technical Stack:**
- Angular 18 with standalone components and lazy loading
- Tailwind CSS for responsive styling
- JWT authentication with role-based access control
- TypeScript with reactive forms
- HttpClient for REST API communication

**Application Architecture:**
Three distinct user roles with dedicated interfaces:

1. **Customer Portal** (/User/):
   - User dashboard with profile management
   - Car registration and management system
   - Service package selection and ordering
   - Addon services selection
   - Review and rating system
   - Coupon/promo code application
   - Payment processing and confirmation

2. **Admin Panel** (/admin/):
   - Comprehensive dashboard with analytics
   - Customer management (view, edit, delete)
   - Washer management and approval
   - Service package configuration
   - Addon services management
   - Coupon/promo code creation and management
   - Order tracking and management
   - Report generation and analytics

3. **Washer Interface** (/washer/):
   - Washer dashboard with earnings overview
   - Profile management and availability settings
   - Available orders browsing and acceptance
   - Current orders management and status updates
   - Order completion and customer interaction

**Core Services:**
- AuthService: JWT handling, login/logout, role management
- CarService: Vehicle CRUD operations
- CustomerService: Customer profile and data management
- WasherService: Washer operations and order management
- PackageService: Service package management
- AddonService: Additional services handling
- PromoCodeService: Coupon and discount management
- OrderService: Order lifecycle management

**Development Standards:**
- Use standalone components exclusively
- Implement lazy loading for all route components
- Apply Tailwind CSS utility classes for styling
- Use reactive forms with proper validation
- Implement proper error handling and loading states
- Follow Angular 18 best practices and conventions
- Maintain consistent file structure and naming
```

## Component Development Prompts

### New Component Creation
```
Create an Angular 18 standalone component for [COMPONENT_NAME] with these requirements:
- Standalone: true with proper imports
- Responsive Tailwind CSS styling
- Reactive forms if user input required
- Service injection for data operations
- Loading states and error handling
- Role-based access control if needed
- Follow project folder structure: /User/, /admin/, or /washer/
- Include proper TypeScript interfaces
- Implement OnInit lifecycle hook
- Add proper component documentation
```

### Service Development
```
Generate an Angular service for [SERVICE_NAME] with:
- @Injectable({ providedIn: 'root' })
- HttpClient injection for API calls
- JWT token handling in headers
- Proper error handling with catchError and retry
- TypeScript interfaces for request/response models
- Observable-based methods
- Place in /core/ directory
- Include proper JSDoc documentation
- Implement loading states management
```

### Route Configuration
```
Add new route to app.routes.ts following these patterns:
- Use loadComponent for lazy loading
- Apply RoleGuard for protected routes
- Follow existing path naming conventions
- Include proper route data and resolve guards
- Implement breadcrumb navigation if needed
- Add route-specific meta tags
```

## Feature-Specific Prompts

### Customer Features
```
Implement customer feature for [FEATURE_NAME]:
- User-friendly interface with Tailwind CSS
- Form validation and error messages
- Integration with backend APIs
- Real-time updates where applicable
- Mobile-responsive design
- Accessibility compliance
- Loading spinners and success notifications
```

### Admin Features
```
Create admin management feature for [FEATURE_NAME]:
- Data table with sorting, filtering, pagination
- CRUD operations with confirmation dialogs
- Bulk actions where applicable
- Export functionality for reports
- Advanced search and filtering
- Role-based permission checks
- Audit trail logging
```

### Washer Features
```
Develop washer interface for [FEATURE_NAME]:
- Real-time order updates
- Status management workflow
- Earnings calculation display
- Location-based order filtering
- Push notification integration
- Offline capability consideration
- Performance optimization for mobile
```

## API Integration Prompts

### HTTP Service Methods
```
Create HTTP service methods for [ENTITY_NAME]:
- GET: Retrieve single and multiple records
- POST: Create new records with validation
- PUT: Update existing records
- DELETE: Remove records with confirmation
- Include proper error handling
- Implement request/response interceptors
- Add loading state management
- Include retry logic for failed requests
```

### Authentication Integration
```
Implement authentication for [COMPONENT_NAME]:
- JWT token validation
- Role-based access control
- Automatic token refresh
- Logout on token expiration
- Route protection with guards
- User session management
- Remember me functionality
```

## Testing Prompts

### Unit Testing
```
Create unit tests for [COMPONENT/SERVICE_NAME]:
- Test component initialization
- Mock service dependencies
- Test user interactions and form submissions
- Validate error handling scenarios
- Test routing and navigation
- Include edge cases and boundary conditions
- Achieve minimum 80% code coverage
```

### Integration Testing
```
Develop integration tests for [FEATURE_NAME]:
- Test complete user workflows
- Mock HTTP requests and responses
- Test component interactions
- Validate data flow between services
- Test authentication and authorization
- Include performance testing scenarios
```

## Deployment and Build Prompts

### Production Build
```
Optimize application for production:
- Configure build optimization settings
- Implement lazy loading strategies
- Optimize bundle sizes
- Configure PWA features if needed
- Set up environment-specific configurations
- Implement proper error logging
- Configure CDN and caching strategies
```

### Performance Optimization
```
Enhance application performance:
- Implement OnPush change detection strategy
- Optimize component rendering
- Add virtual scrolling for large lists
- Implement image lazy loading
- Optimize HTTP requests with caching
- Add service worker for offline functionality
- Monitor and optimize Core Web Vitals
```