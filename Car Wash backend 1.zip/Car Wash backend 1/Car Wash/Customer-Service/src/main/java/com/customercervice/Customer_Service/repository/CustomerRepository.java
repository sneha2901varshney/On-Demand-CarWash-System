    package com.customercervice.Customer_Service.repository;

    import com.customercervice.Customer_Service.entity.Customer;
    import org.springframework.data.jpa.repository.JpaRepository;

    import java.util.Optional;

    public interface CustomerRepository extends JpaRepository<Customer, Long> {

        // Find customer by email
        Optional<Customer> findByEmail(String email);
    }
