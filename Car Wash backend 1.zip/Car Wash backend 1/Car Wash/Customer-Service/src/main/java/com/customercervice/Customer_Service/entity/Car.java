package com.customercervice.Customer_Service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "cars")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Car brand is required")
    @Column(nullable = false)
    private String brand;

    @NotBlank(message = "Car model is required")
    @Column(nullable = false)
    private String model;

    @NotBlank(message = "Car color is required")
    @Column(nullable = false)
    private String color;

    @NotBlank(message = "License plate is required")
    @Size(max = 20, message = "License plate must not exceed 20 characters")
    @Column(nullable = false)
    private String licensePlate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    @NotNull(message = "Customer reference is required")
    private Customer customer;
}
