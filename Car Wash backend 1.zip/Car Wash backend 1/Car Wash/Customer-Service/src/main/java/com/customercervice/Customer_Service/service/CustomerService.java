package com.customercervice.Customer_Service.service;

import com.customercervice.Customer_Service.dto.CustomerDTO;

import java.util.List;

public interface CustomerService {

    CustomerDTO registerCustomer(CustomerDTO customerDTO);

    CustomerDTO getCustomerById(Long id);

    List<CustomerDTO> getAllCustomers();

    CustomerDTO updateCustomer(Long id, CustomerDTO customerDTO);

    void deleteCustomer(Long id);

    CustomerDTO getCustomerByEmail(String email);
}
