package com.customercervice.Customer_Service.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "reviews")
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Customer ID is required")
    @Column(nullable = false)
    private Long customerId;

    @NotNull(message = "Washer ID is required")
    @Column(nullable = false)
    private Long washerId;

    @Min(value = 1, message = "Rating must be at least 1")
    @Max(value = 5, message = "Rating must not exceed 5")
    @Column(nullable = false)
    private int rating;

    @Size(max = 500, message = "Comment must not exceed 500 characters")
    @Column(length = 500)
    private String comment;

    @NotNull(message = "Created date and time is required")
    @Column(nullable = false)
    private LocalDateTime createdAt;
}
