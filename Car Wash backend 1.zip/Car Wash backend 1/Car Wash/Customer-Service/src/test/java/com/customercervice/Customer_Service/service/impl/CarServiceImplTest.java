package com.customercervice.Customer_Service.service.impl;


import com.customercervice.Customer_Service.dto.CarDTO;
import com.customercervice.Customer_Service.entity.Car;
import com.customercervice.Customer_Service.entity.Customer;
import com.customercervice.Customer_Service.repository.CarRepository;
import com.customercervice.Customer_Service.repository.CustomerRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CarServiceImplTest {
    @Mock
    private CarRepository carRepository;

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CarServiceImpl carService;
    private Customer customer;
    private Car car;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        customer = new Customer();
        customer.setId(1L);
        customer.setFullName("John Doe");
        customer.setEmail("john@example.com");
        customer.setPassword("password");
        customer.setPhone("1234567890");
        car = new Car();
        car.setId(10L);
        car.setBrand("Toyota");
        car.setModel("Corolla");
        car.setColor("Red");
        car.setLicensePlate("ABC123");
        car.setCustomer(customer);
    }

    @Test
    void testAddCar_Success() {
        CarDTO carDTO = new CarDTO(null, "Toyota", "Corolla", "Red", "ABC123", 1L);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(carRepository.save(any(Car.class))).thenReturn(car);
        CarDTO result = carService.addCar(carDTO);
        assertNotNull(result);
        assertEquals("Toyota", result.getBrand());
        assertEquals(1L, result.getCustomerId());
    }
    @Test
    void testAddCar_CustomerNotFound() {
        CarDTO carDTO = new CarDTO(null, "Toyota", "Corolla", "Red", "ABC123", 99L);
        when(customerRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> carService.addCar(carDTO));
    }
    @Test
    void testGetCarsByCustomerId_Success() {
        List<Car> cars = List.of(car);
        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(carRepository.findByCustomer(customer)).thenReturn(cars);
        List<CarDTO> carDTOs = carService.getCarsByCustomerId(1L);
        assertEquals(1, carDTOs.size());
        assertEquals("Toyota", carDTOs.get(0).getBrand());
    }
    @Test
    void testGetCarsByCustomerId_CustomerNotFound() {
        when(customerRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> carService.getCarsByCustomerId(99L));
    }
    @Test
    void testUpdateCar_Success() {
        CarDTO updatedDTO = new CarDTO(null, "Honda", "Civic", "Blue", "XYZ789", 1L);
        when(carRepository.findById(10L)).thenReturn(Optional.of(car));
        when(carRepository.save(any(Car.class))).thenAnswer(i -> i.getArgument(0));
        CarDTO result = carService.updateCar(10L, updatedDTO);
        assertEquals("Honda", result.getBrand());
        assertEquals("Blue", result.getColor());
    }
    @Test
    void testUpdateCar_NotFound() {
        CarDTO dto = new CarDTO(null, "Honda", "Civic", "Blue", "XYZ789", 1L);
        when(carRepository.findById(999L)).thenReturn(Optional.empty());
        assertThrows(EntityNotFoundException.class, () -> carService.updateCar(999L, dto));
    }
    @Test
    void testDeleteCar_Success() {
        when(carRepository.existsById(10L)).thenReturn(true);
        carService.deleteCar(10L);
        verify(carRepository, times(1)).deleteById(10L);
    }
    @Test
    void testDeleteCar_NotFound() {
        when(carRepository.existsById(999L)).thenReturn(false);
        assertThrows(EntityNotFoundException.class, () -> carService.deleteCar(999L));
    }
}