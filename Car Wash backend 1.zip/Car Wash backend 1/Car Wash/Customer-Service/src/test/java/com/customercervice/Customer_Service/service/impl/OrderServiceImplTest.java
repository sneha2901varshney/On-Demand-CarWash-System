package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.client.OrderClient;
import com.customercervice.Customer_Service.dto.OrderDTO;
import com.customercervice.Customer_Service.service.impl.OrderServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrderServiceImplTest {
    @Mock
    private OrderClient orderClient;

    @InjectMocks
    private OrderServiceImpl orderService;

    private OrderDTO orderDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        orderDTO = new OrderDTO();
        orderDTO.setId(1L);
        orderDTO.setCustomerId(101L);
        orderDTO.setWasherId(201L);
        orderDTO.setCarModel("Model S");
        orderDTO.setCarNumber("ABC123");
        orderDTO.setCarName("Tesla");
        orderDTO.setPackageName("Premium");
        orderDTO.setAddOns("Wax");
        orderDTO.setStatus("Scheduled");
        orderDTO.setLocation("Downtown");
        orderDTO.setWashDate(LocalDate.now());
        orderDTO.setScheduleDate(LocalDate.now().plusDays(1));
    }
    @Test
    void testGetCurrentOrders() {
        Long customerId = 101L;
        List<OrderDTO> mockOrders = Arrays.asList(orderDTO);
        when(orderClient.getCurrentOrders(customerId)).thenReturn(mockOrders);
        List<OrderDTO> result = orderService.getCurrentOrders(customerId);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Tesla", result.get(0).getCarName());
        verify(orderClient, times(1)).getCurrentOrders(customerId);
    }
    @Test
    void testGetPastOrders() {
        Long customerId = 101L;
        List<OrderDTO> pastOrders = Arrays.asList(orderDTO);
        when(orderClient.getPastOrders(customerId)).thenReturn(pastOrders);
        List<OrderDTO> result = orderService.getPastOrders(customerId);
        assertEquals(1, result.size());
        assertEquals("Premium", result.get(0).getPackageName());
        verify(orderClient, times(1)).getPastOrders(customerId);
    }
    @Test
    void testCreateOrder() {
        when(orderClient.createOrder(orderDTO)).thenReturn(orderDTO);
        OrderDTO result = orderService.createOrder(orderDTO);
        assertNotNull(result);
        assertEquals("Tesla", result.getCarName());
        verify(orderClient, times(1)).createOrder(orderDTO);
    }
}
