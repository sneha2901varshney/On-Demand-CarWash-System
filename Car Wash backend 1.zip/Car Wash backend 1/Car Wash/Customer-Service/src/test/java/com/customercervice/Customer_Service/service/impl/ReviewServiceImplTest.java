package com.customercervice.Customer_Service.service.impl;

import com.customercervice.Customer_Service.dto.ReviewDTO;
import com.customercervice.Customer_Service.entity.Review;
import com.customercervice.Customer_Service.repository.ReviewRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReviewServiceImplTest {
    @Mock
    private ReviewRepository reviewRepository;

    @InjectMocks
    private ReviewServiceImpl reviewService;

    private Review review;
    private ReviewDTO reviewDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        review = new Review();
        review.setId(1L);
        review.setCustomerId(101L);
        review.setWasherId(303L);
        review.setRating(5);
        review.setComment("Excellent service!");
        review.setCreatedAt(LocalDateTime.now());
        reviewDTO = new ReviewDTO( 1L, 101L, 303L, 5, "Excellent service!"        );
    }
    @Test
    void testSubmitReview() {
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        ReviewDTO result = reviewService.submitReview(reviewDTO);
        assertNotNull(result);
        assertEquals(review.getCustomerId(), result.getCustomerId());
        assertEquals("Excellent service!", result.getComment());
        verify(reviewRepository, times(1)).save(any(Review.class));
    }
    @Test void testGetReviewsByCustomerId() {
        when(reviewRepository.findByCustomerId(101L)).thenReturn(Arrays.asList(review));
        List<ReviewDTO> reviews = reviewService.getReviewsByCustomerId(101L);
        assertEquals(1, reviews.size());
        assertEquals(5, reviews.get(0).getRating());
        verify(reviewRepository, times(1)).findByCustomerId(101L);
    }
    @Test
    void testGetReviewsByWasherId() {
        when(reviewRepository.findByWasherId(303L)).thenReturn(List.of(review));
        List<ReviewDTO> reviews = reviewService.getReviewsByWasherId(303L);
        assertEquals(1, reviews.size());
        assertEquals(303L, reviews.get(0).getWasherId());
        verify(reviewRepository, times(1)).findByWasherId(303L);
    }
    @Test
    void testGetAllWasherReviews() {
        when(reviewRepository.findByWasherIdIsNotNull()).thenReturn(List.of(review));
        List<ReviewDTO> reviews = reviewService.getAllWasherReviews();
        assertFalse(reviews.isEmpty());
        assertEquals("Excellent service!", reviews.get(0).getComment());
        verify(reviewRepository, times(1)).findByWasherIdIsNotNull();
    }
}


