package com.carwash.payment_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Entity
@Data
public class PaymentInfo {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private String customerName;
    private String customerId;
    private String packageName;
    private String orderId;
    private Double Amount;


    @Column(name = "payment_status")
    private String paymentStatus;
    private String currency;

    @Column(unique = true)
    private String sessionId;
    private String paymentIntentId;
    @Column(length = 512)
    private String sessionUrl;
    private LocalDateTime createdAt = LocalDateTime.now();


    // Getters and Setters
}

