package com.carwash.payment_service.client;

import com.carwash.payment_service.dto.OrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "ORDER-SERVICE")
public interface OrderClient {
    @GetMapping("/api/orders/{id}")
    OrderDTO getOrderById(@PathVariable Long id);

//    @PutMapping("/api/orders/status/{id}")
//    OrderDTO updateOrderStatus(@PathVariable Long id, @RequestParam String status);
//
//    @DeleteMapping("/api/orders/delete/{id}")
//    void deleteOrder(@PathVariable Long id);
}
