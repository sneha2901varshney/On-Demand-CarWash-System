package com.carwash.payment_service.dto;


import jakarta.persistence.Entity;
import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor

public class PaymentResponse {
    private String sessionUrl;

    public PaymentResponse(String sessionUrl) {
        this.sessionUrl = sessionUrl;
    }

    public String getSessionUrl() {
        return sessionUrl;
    }

    public void setSessionUrl(String sessionUrl) {
        this.sessionUrl = sessionUrl;
    }
}


