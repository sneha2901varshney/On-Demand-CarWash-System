package com.carwash.auth_service.service;

import com.carwash.auth_service.client.CustomerClient;
import com.carwash.auth_service.client.WasherClient;
import com.carwash.auth_service.dto.CustomerDTO;
import com.carwash.auth_service.dto.RegisterRequest;
import com.carwash.auth_service.dto.WasherDTO;
import com.carwash.auth_service.entity.User;
import com.carwash.auth_service.repository.UserRepository;
import com.carwash.auth_service.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    CustomerClient customerClient;

    @Autowired
    WasherClient washerClient;

    public String register(RegisterRequest user) {
        if (userRepo.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("User already exists");
        }
        User orgUser = new User();
        orgUser.setEmail(user.getEmail());
        orgUser.setUsername(user.getUsername());
        orgUser.setRole(user.getRole());
        orgUser.setFullName(user.getFullName());
        orgUser.setPassword(passwordEncoder.encode(user.getPassword()));

//        if(user.getRole().equals("Admin")){
//            throw new UserAlreadyExistsException("Admin Already exists can't have multiple admins");
//        }

        if(user.getRole().equals("Customer")){
            CustomerDTO customerDTO=new CustomerDTO(user.getFullName(),user.getEmail(), user.getPassword());
            customerClient.saveCustomer(customerDTO);
        }

        else if(user.getRole().equals("Washer")){
            WasherDTO washerDTO=new WasherDTO(user.getFullName(),user.getEmail(), user.getPassword())  ;
            washerClient.createWasher(washerDTO);
        }
        return userRepo.save(orgUser).getEmail() + " registered";
    }

    public String login(String email, String password) {
        Optional<User> user = userRepo.findByEmail(email);
        if (user.isEmpty()) throw new RuntimeException("User not found");
        if (!passwordEncoder.matches(password, user.get().getPassword())) {
            throw new RuntimeException("Invalid password");
        }
        return jwtUtil.generateToken(email, user.get().getRole());
    }
}
