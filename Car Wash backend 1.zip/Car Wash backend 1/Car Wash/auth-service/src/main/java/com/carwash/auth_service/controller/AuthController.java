package com.carwash.auth_service.controller;

import com.carwash.auth_service.dto.LoginRequest;
import com.carwash.auth_service.dto.LoginResponse;
import com.carwash.auth_service.dto.RegisterRequest;
import com.carwash.auth_service.entity.User;
import com.carwash.auth_service.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@Valid @RequestBody RegisterRequest user) {
        try {
            String result = authService.register(user);
            Map<String, String> response = new HashMap<>();
            response.put("message", result);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            String token = authService.login(loginRequest.getEmail(),
                    loginRequest.getPassword());
            return ResponseEntity.ok(new LoginResponse(token, "Login Successful!"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new LoginResponse(null, e.getMessage()));
        }
    }
}
