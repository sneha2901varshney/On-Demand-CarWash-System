package com.carwash.auth_service.dto;




import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class WasherDTO {

    private String fullName;
    private String email;
    private String password;




}

