package com.carwash.auth_service;

import com.carwash.auth_service.entity.User;
import com.carwash.auth_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class AuthServiceApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(AuthServiceApplication.class, args);


	}

	@Override
	public void run(String... args) throws Exception {
		User adminAccount = userRepository.findByRole("Admin");
		if (adminAccount == null){
			User user = new User();
			user.setEmail("snehavarshney2901@gmail.com");
			user.setUsername("Sneha2901");
			user.setRole("Admin");
			user.setFullName("Sneha2901");
			user.setPassword(new BCryptPasswordEncoder().encode("sneha2901@"));
			userRepository.save(user);
		}
	}

}
