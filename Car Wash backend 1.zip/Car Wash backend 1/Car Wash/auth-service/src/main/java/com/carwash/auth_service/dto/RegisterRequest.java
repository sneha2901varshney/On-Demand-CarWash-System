package com.carwash.auth_service.dto;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    private String email;
    private String password;

    private String role;
    private String username;
    private String fullName;
    // optional based on use-case    // Getters and Setters
 }