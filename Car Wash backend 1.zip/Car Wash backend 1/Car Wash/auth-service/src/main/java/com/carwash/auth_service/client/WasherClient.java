package com.carwash.auth_service.client;


import com.carwash.auth_service.dto.WasherDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "WASHER-SERVICE")
public interface WasherClient {
    @PostMapping("/api/washers/create")
    WasherDTO createWasher(WasherDTO washer);
}
