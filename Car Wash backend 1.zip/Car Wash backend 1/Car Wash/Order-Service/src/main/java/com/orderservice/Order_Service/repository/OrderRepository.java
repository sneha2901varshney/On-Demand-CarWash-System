package com.orderservice.Order_Service.repository;

import com.orderservice.Order_Service.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerId(Long customerId);
    List<Order> findByWasherId(Long washerId);

    Collection<Order> findByCustomerIdAndStatus(Long customerId, String pending);

    Collection<Order> findByCustomerIdAndStatusNot(Long customerId, String pending);
}
