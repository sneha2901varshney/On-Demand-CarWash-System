package com.orderservice.Order_Service.controller;

import com.orderservice.Order_Service.controller.OrderController;
import com.orderservice.Order_Service.dto.OrderDTO;
import com.orderservice.Order_Service.enums.PackageType;
import com.orderservice.Order_Service.enums.PaymentStatus;
import com.orderservice.Order_Service.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class OrderControllerTest {
    @InjectMocks
    private OrderController orderController;

    @Mock
    private OrderService orderService;

    private OrderDTO orderDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        orderDTO = new OrderDTO();
        orderDTO.setId(1L);
        orderDTO.setCustomerId(101L);
        orderDTO.setWasherId(202L);
        orderDTO.setCarModel("Model X");
        orderDTO.setCarNumber("MH12AB1234");
        orderDTO.setCarName("Tesla");
        orderDTO.setPackageName(PackageType.PREMIUM);
        orderDTO.setAddOns("Tire Polish");
        orderDTO.setStatus("Scheduled");
        orderDTO.setWashDate(LocalDate.now().plusDays(1));
        orderDTO.setScheduleDate(LocalDate.now().plusDays(1));
        orderDTO.setLocation("Pune");
        orderDTO.setPaymentStatus(PaymentStatus.ACCEPTED);
        orderDTO.setPrice(999.99);
    }
    @Test
    void testCreateOrder() {
        when(orderService.createOrder(any(OrderDTO.class))).thenReturn(orderDTO);
        ResponseEntity<OrderDTO> response = orderController.create(orderDTO);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(orderDTO, response.getBody());
        verify(orderService).createOrder(orderDTO);
    }
    @Test
    void testGetOrderById() {
        when(orderService.getOrderById(1L)).thenReturn(orderDTO);
        ResponseEntity<OrderDTO> response = orderController.getById(1L);
        assertEquals(orderDTO, response.getBody());
        verify(orderService).getOrderById(1L);
    }
    @Test
    void testGetAllOrders() {
        when(orderService.getAllOrders()).thenReturn(List.of(orderDTO));
        ResponseEntity<List<OrderDTO>> response = orderController.getAll();
        assertEquals(1, response.getBody().size());
        verify(orderService).getAllOrders();
    }
    @Test
    void testGetOrdersByCustomerId() {
        when(orderService.getOrdersByCustomerId(101L)).thenReturn(List.of(orderDTO));
        ResponseEntity<List<OrderDTO>> response = orderController.getByCustomer(101L);
        assertEquals(1, response.getBody().size());
        verify(orderService).getOrdersByCustomerId(101L);
    }
    @Test
    void testGetOrdersByWasherId() {
        when(orderService.getOrdersByWasherId(202L)).thenReturn(List.of(orderDTO));
        ResponseEntity<List<OrderDTO>> response = orderController.getByWasher(202L);
        assertEquals(1, response.getBody().size());
        verify(orderService).getOrdersByWasherId(202L);
    }
    @Test
    void testUpdateOrder() {
        when(orderService.updateOrder(eq(1L), any(OrderDTO.class))).thenReturn(orderDTO);
        ResponseEntity<OrderDTO> response = orderController.update(1L, orderDTO);
        assertEquals(orderDTO, response.getBody());
        verify(orderService).updateOrder(1L, orderDTO);
    }
    @Test
    void testDeleteOrder() {
        doNothing().when(orderService).deleteOrder(1L);
        ResponseEntity<String> response = orderController.delete(1L);
        assertEquals("Order deleted successfully.", response.getBody());
        verify(orderService).deleteOrder(1L);
    }
    @Test
    void testUpdateOrderStatus() {
        when(orderService.updateOrderStatus(1L, "Completed")).thenReturn(orderDTO);
        ResponseEntity<OrderDTO> response = orderController.updateStatus(1L, "Completed");
        assertEquals(orderDTO, response.getBody());
        verify(orderService).updateOrderStatus(1L, "Completed");
    }
    @Test
    void testGetCurrentOrders() {
        when(orderService.getCurrentOrders(101L)).thenReturn(List.of(orderDTO));
        ResponseEntity<List<OrderDTO>> response = orderController.getCurrentOrders(101L);
        assertEquals(1, response.getBody().size());
        verify(orderService).getCurrentOrders(101L);
    }
    @Test
    void testGetPastOrders() {
        when(orderService.getPastOrders(101L)).thenReturn(List.of(orderDTO));
        ResponseEntity<List<OrderDTO>> response = orderController.getPastOrders(101L);
        assertEquals(1, response.getBody().size());
        verify(orderService).getPastOrders(101L);
    }
}