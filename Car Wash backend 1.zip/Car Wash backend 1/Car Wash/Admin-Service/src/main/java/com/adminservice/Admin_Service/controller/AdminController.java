package com.adminservice.Admin_Service.controller;

import com.adminservice.Admin_Service.dto.AdminDTO;
import com.adminservice.Admin_Service.dto.CustomerDTO;
import com.adminservice.Admin_Service.dto.OrderDTO;
import com.adminservice.Admin_Service.dto.WasherDTO;
import com.adminservice.Admin_Service.service.AdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Admin-related operations.
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    private final AdminService adminService;

    @Autowired
    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // Endpoint to get admin details by email
    @GetMapping("/email/{email}")
    public ResponseEntity<AdminDTO> getAdminByEmail(@Valid @PathVariable String email) {
        return ResponseEntity.ok(adminService.getAdminByEmail(email));
    }


//    Customer using Feign
        @GetMapping("/customers")
        public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
            return ResponseEntity.ok(adminService.getAllCustomers());
        }

    @GetMapping("/washers")
    public ResponseEntity<List<WasherDTO>> fetchAllWashers() {
        return ResponseEntity.ok(adminService.fetchAllWashers());
    }

    @PostMapping("/washer")
    public ResponseEntity<Void> createWasher(@RequestBody @Valid WasherDTO washerDTO) {
        adminService.createWasher(washerDTO);
        return ResponseEntity.noContent().build();
    }




    // DELETE washer
    @DeleteMapping("/washer/{id}")
    public ResponseEntity<Void> deleteWasher(@Valid @PathVariable Long id) {
        adminService.deleteWasher(id);
        return ResponseEntity.noContent().build();
    }

    // DELETE customer
    @DeleteMapping("/customer/{id}")
    public ResponseEntity<Void> deleteCustomer(@Valid @PathVariable Long id) {
        adminService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }

    // GET all orders
    @GetMapping("/orders")
    public ResponseEntity<List<OrderDTO>> getAllOrders() {
        return ResponseEntity.ok(adminService.getAllOrders());
    }

    // UPDATE order status
    @PutMapping("/order/{id}/status")
    public ResponseEntity<OrderDTO> updateOrderStatus(@Valid @PathVariable Long id, @Valid @RequestParam String status
    ) {
        return ResponseEntity.ok(adminService.updateOrderStatus(id, status));
    }

    // DELETE order
    @DeleteMapping("/order/{id}")
    public ResponseEntity<String> deleteOrder(@Valid @PathVariable Long id) {
        adminService.deleteOrder(id);
        return ResponseEntity.ok("Order Deleted Successfully.");
    }




}
