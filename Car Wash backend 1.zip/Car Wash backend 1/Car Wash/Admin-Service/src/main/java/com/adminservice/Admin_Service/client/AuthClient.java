package com.adminservice.Admin_Service.client;

import com.adminservice.Admin_Service.dto.AuthDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@FeignClient(name = "AUTH-SERVICE")
public interface AuthClient {

    @PostMapping("/auth/register")
    void registerUser(@RequestBody AuthDTO userDTO);
}
