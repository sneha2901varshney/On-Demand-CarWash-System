package com.adminservice.Admin_Service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuthDTO {
    private String email;
    private String password;
    private String role;
    private String username;
    private String fullName;
}


