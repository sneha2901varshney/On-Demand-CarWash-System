package com.adminservice.Admin_Service.dto;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderDTO {

    private Long id;

    @NotNull(message = "Customer ID is required")
    private Long customerId;

    @NotNull(message = "Washer ID is required")
    private Long washerId;

    @NotBlank(message = "Car model is required")
    private String carModel;

    @NotBlank(message = "Car number is required")
    private String carNumber;

    @NotBlank(message = "Car name is required")
    private String carName;

    private String packageName;


    private String addOns;

    @NotBlank(message = "Order status is required")
    private String status;

    @FutureOrPresent(message = "Wash date cannot be in the past")
    private LocalDate washDate;

    @FutureOrPresent(message = "Schedule date cannot be in the past")
    private LocalDate scheduleDate;

    @NotBlank(message = "Location is required")
    private String location;

    private String paymentStatus;

    private Double price;


}
