package com.adminservice.Admin_Service.client;

import com.adminservice.Admin_Service.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

//@FeignClient(name = "customer-service", url = "http://localhost:8081") // Name as registered in Eureka
@FeignClient(name = "CUSTOMER-SERVICE")
public interface CustomerClient {

    @GetMapping("/api/customers")
    List<CustomerDTO> fetchAllCustomers();

    @DeleteMapping("/api/customers/{id}")
    void deleteCustomer(@PathVariable Long id);
}
