package com.adminservice.Admin_Service.service;


import com.adminservice.Admin_Service.client.CustomerClient;
import com.adminservice.Admin_Service.client.OrderClient;
import com.adminservice.Admin_Service.client.WasherClient;
import com.adminservice.Admin_Service.dto.*;
import com.adminservice.Admin_Service.entity.Admin;
import com.adminservice.Admin_Service.repository.AdminRepository;
import com.adminservice.Admin_Service.service.impl.AdminServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;import org.springframework.test.util.ReflectionTestUtils;
import java.util.List;import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ServiceTest {
    @Mock
    private AdminRepository adminRepository;

    @Mock
    private CustomerClient customerClient;

    @Mock
    private WasherClient washerClient;

    @Mock
    private OrderClient orderClient;

    @InjectMocks
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        adminService = new AdminServiceImpl(adminRepository);
        // manually inject mocks into autowired fields
         ReflectionTestUtils.setField(adminService, "customerClient", customerClient);
         ReflectionTestUtils.setField(adminService, "orderClient", orderClient);
         ReflectionTestUtils.setField(adminService, "washerClient", washerClient);
    }
    @Test
    void getAdminByEmail_shouldReturnAdminDTO() {
        Admin admin = new Admin();
        admin.setId(1L);
        admin.setFullName("John Doe");
        admin.setEmail("admin@example.com");
        admin.setPassword("password");
        when(adminRepository.findByEmail("admin@example.com")).thenReturn(Optional.of(admin));
        AdminDTO result = adminService.getAdminByEmail("admin@example.com");
        assertNotNull(result);
        assertEquals("admin@example.com", result.getEmail());
        assertEquals("John Doe", result.getFullName());
    }
    @Test
    void getAllCustomers_shouldReturnList() {
        CustomerDTO customer = new CustomerDTO();
        customer.setFullName("Alice");
        customer.setEmail("alice@example.com");
        when(customerClient.fetchAllCustomers()).thenReturn(List.of(customer));
        List<CustomerDTO> result = adminService.getAllCustomers();
        assertEquals(1, result.size());
        assertEquals("Alice", result.get(0).getFullName());
    }
    @Test
    void fetchAllWashers_shouldReturnList() {
        WasherDTO washer = new WasherDTO();
        washer.setName("Washer One");
        washer.setEmail("washer@example.com");
        when(washerClient.getAllWashers()).thenReturn(List.of(washer));
        List<WasherDTO> result = adminService.fetchAllWashers();
        assertEquals(1, result.size());
        assertEquals("Washer One", result.get(0).getName());
    }
    @Test
    void createWasher_shouldReturnWasherDTO() {
        WasherDTO washer = new WasherDTO();
        washer.setName("Washer A");
        washer.setEmail("washer@example.com");
        when(washerClient.registerWasher(washer)).thenReturn(washer);
        WasherDTO result = adminService.createWasher(washer);
        assertEquals("washer@example.com", result.getEmail());
    }
    @Test
    void deleteWasher_shouldCallClient() {
        adminService.deleteWasher(100L);
        verify(washerClient).deleteWasher(100L);
    }
    @Test
    void deleteCustomer_shouldCallClient() {
        adminService.deleteCustomer(200L);
        verify(customerClient).deleteCustomer(200L);
    }
    @Test
    void getAllOrders_shouldReturnList() {
        OrderDTO order = new OrderDTO();
        order.setId(1L);
        order.setStatus("PENDING");
        when(orderClient.getAllOrders()).thenReturn(List.of(order));
        List<OrderDTO> result = adminService.getAllOrders();
        assertEquals(1, result.size());
        assertEquals("PENDING", result.get(0).getStatus());
    }
    @Test
    void updateOrderStatus_shouldReturnUpdatedOrder() {
        OrderDTO updated = new OrderDTO();
        updated.setId(1L);
        updated.setStatus("COMPLETED");
        when(orderClient.updateOrderStatus(1L, "COMPLETED")).thenReturn(updated);
        OrderDTO result = adminService.updateOrderStatus(1L, "COMPLETED");
        assertEquals("COMPLETED", result.getStatus());
    }
    @Test
    void deleteOrder_shouldCallClient() {
        adminService.deleteOrder(300L);
        verify(orderClient).deleteOrder(300L);
    }
}
