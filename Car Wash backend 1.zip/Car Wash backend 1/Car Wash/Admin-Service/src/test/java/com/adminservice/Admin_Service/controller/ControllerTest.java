package com.adminservice.Admin_Service.controller;

import com.adminservice.Admin_Service.dto.*;
import com.adminservice.Admin_Service.service.AdminService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminController.class)
class ControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminService adminService;

    @Test
    void testGetAdminByEmail() throws Exception {
        AdminDTO admin = new AdminDTO();
        admin.setEmail("admin@example.com");
        Mockito.when(adminService.getAdminByEmail("admin@example.com")).thenReturn(admin);
        mockMvc.perform(get("/api/admin/email/admin@example.com"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("admin@example.com"));
    }

    @Test
    void testGetAllCustomers() throws Exception {
        CustomerDTO customer = new CustomerDTO();
        customer.setFullName("John ");
        Mockito.when(adminService.getAllCustomers()).thenReturn(List.of(customer));
        mockMvc.perform(get("/api/admin/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }
    @Test
    void testFetchAllWashers() throws Exception {
        WasherDTO washer = new WasherDTO();
        washer.setName("Washer1");
        Mockito.when(adminService.fetchAllWashers()).thenReturn(List.of(washer));
        mockMvc.perform(get("/api/admin/washers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }
    @Test
    void testCreateWasher() throws Exception {
        WasherDTO washer = new WasherDTO();
        washer.setName("Washer1");
        Mockito.when(adminService.createWasher(any(WasherDTO.class))).thenReturn(washer);
        String json = """          
              {        
                   "name": "Washer1",    
                   "email": "washer@example.com",    
                   "password": "pass"      
                   }            
               """;
        mockMvc.perform(post("/api/admin/washer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Washer1"));
    }
    @Test
    void testDeleteWasher() throws Exception {
        mockMvc.perform(delete("/api/admin/washer/1"))
                .andExpect(status().isNoContent());
        verify(adminService).deleteWasher(1L);
    }
    @Test
    void testDeleteCustomer() throws Exception {
        mockMvc.perform(delete("/api/admin/customer/2"))
                .andExpect(status().isNoContent());
        verify(adminService).deleteCustomer(2L);
    }
    @Test
    void testGetAllOrders() throws Exception {
        OrderDTO order = new OrderDTO();
        order.setId(1L);
        Mockito.when(adminService.getAllOrders()).thenReturn(List.of(order));
        mockMvc.perform(get("/api/admin/orders"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)));
    }
    @Test
    void testUpdateOrderStatus() throws Exception {
        OrderDTO order = new OrderDTO();
        order.setId(1L);
        order.setStatus("COMPLETED");
        Mockito.when(adminService.updateOrderStatus(eq(1L), eq("COMPLETED"))).thenReturn(order);
        mockMvc.perform(put("/api/admin/order/1/status?status=COMPLETED"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("COMPLETED"));
    }
    @Test
    void testDeleteOrder() throws Exception {
        doNothing().when(adminService).deleteOrder(3L);

        mockMvc.perform(delete("/api/admin/order/3"))
                .andExpect(status().isOk()) // HTTP 200
                .andExpect(content().string("Order Deleted Successfully."));

        verify(adminService).deleteOrder(3L);

    }
}