package com.washerservice.Washer_Service.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.washerservice.Washer_Service.dto.OrderDTO;
import com.washerservice.Washer_Service.dto.ReviewDTO;
import com.washerservice.Washer_Service.dto.WasherDTO;
import com.washerservice.Washer_Service.service.WasherService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(WasherController.class)
public class WasherControllerImplTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private WasherService washerService;

    @Autowired
    private ObjectMapper objectMapper;

    private
    WasherDTO washerDTO;


    @BeforeEach
    void setUp() {
        washerDTO = new WasherDTO(1L, "John Doe", "john@example.com", "1234567890", "password123");
    }

    @Test
    void testCreateWasher() throws Exception {
        when(washerService.registerWasher(ArgumentMatchers.any(WasherDTO.class))).thenReturn(washerDTO);
        mockMvc.perform(post("/api/washers/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(washerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"));
    }
    @Test
    void testGetAllWashers() throws Exception {
        List<WasherDTO> washerList = Arrays.asList(washerDTO);
        when(washerService.getAllWashers()).thenReturn(washerList);
        mockMvc.perform(get("/api/washers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
    @Test
    void testGetWasherById() throws Exception {
        when(washerService.getWasherById(1L)).thenReturn(washerDTO);
        mockMvc.perform(get("/api/washers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L));
    }
    @Test
    void testUpdateWasher() throws Exception {
        when(washerService.updateWasher(ArgumentMatchers.eq(1L), ArgumentMatchers.any(WasherDTO.class)))
                .thenReturn(washerDTO);
        mockMvc.perform(put("/api/washers/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(washerDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"));
    }
    @Test
    void testDeleteWasher() throws Exception {
        mockMvc.perform(delete("/api/washers/1"))
                .andExpect(status().isNoContent());
    }
    @Test
    void testGetCurrentOrders() throws Exception {
        OrderDTO order = new OrderDTO(); // You may want to populate with fields
        when(washerService.getCurrentOrders(1L)).thenReturn(List.of(order));
        mockMvc.perform(get("/api/washers/1/orders/current"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
    @Test
    void testGetPastOrders() throws Exception {
        OrderDTO order = new OrderDTO();
        when(washerService.getPastOrders(1L)).thenReturn(List.of(order));
        mockMvc.perform(get("/api/washers/1/orders/past"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
    @Test
    void testAcceptOrder() throws Exception {
        OrderDTO order = new OrderDTO();
        when(washerService.acceptOrder(10L)).thenReturn(order);
        mockMvc.perform(put("/api/washers/orders/10/accept"))
                .andExpect(status().isOk());
    }

    @Test
    void testDeclineOrder() throws Exception {
        OrderDTO order = new OrderDTO();
        when(washerService.declineOrder(10L)).thenReturn(order);
        mockMvc.perform(put("/api/washers/orders/10/decline"))
                .andExpect(status().isOk());
    }
    @Test
    void testGetWasherReviews() throws Exception {
        ReviewDTO review = new ReviewDTO();
        when(washerService.getReviewsForWasher(1L)).thenReturn(List.of(review));
        mockMvc.perform(get("/api/washers/reviews/washer/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1));
    }
}

