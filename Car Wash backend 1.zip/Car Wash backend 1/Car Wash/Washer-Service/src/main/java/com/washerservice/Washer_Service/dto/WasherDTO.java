package com.washerservice.Washer_Service.dto;


import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class WasherDTO {

    private Long id;
    private String fullName;
    private String email;
    private String phone;
    private String password;



}
