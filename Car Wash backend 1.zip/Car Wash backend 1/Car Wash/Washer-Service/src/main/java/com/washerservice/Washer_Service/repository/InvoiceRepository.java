package com.washerservice.Washer_Service.repository;

import com.washerservice.Washer_Service.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    List<Invoice> findByWasherId(Long washerId);

    List<Invoice> findByOrderId(Long orderId);
}
